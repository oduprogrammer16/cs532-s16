from gender_detector import *

__copyright__ = 'Copyright (c) 2014 Marcos Vanetta'

version = (0,0,4)
version_string = "Gender Detector version %d.%d.%d" % version
